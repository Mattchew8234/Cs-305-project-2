package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;


@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {

		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
@RestController
class ServerController {
	private static final char[] hex = "0123456789ABCDEF".toCharArray();
	private String hash(String input) {
		try {
			MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
			byte[] messageD = messageDigest.digest();
			return bytesToHex(messageD);
		} catch(NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return input;
	}	
	
	private static String bytesToHex(byte[] bytes) {
		char[] chars = new char[bytes.length * 2];
		for(int count = 0; count < bytes.length; count++) {
			int key = bytes[count] & 0xFF;
			chars[count * 2] =  hex[key >>> 4];
			chars[count * 2 + 1] = hex[key & 0x0F];
			System.out.print(count + "\n");
		}
		return new String(chars);
	}

	@RequestMapping("/hash")
	public String myHash() {
		String name = "Hello world check sum by Matthew!";
		
		String hashname = hash(name);
		return "<p>Creator: " + name + "</p><p> Name of Cipher Used: SHA-256 Value: " + hashname;
	}
}